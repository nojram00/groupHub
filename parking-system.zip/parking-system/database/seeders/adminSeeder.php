<?php

namespace Database\Seeders;

use App\Models\admin;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class adminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // \App\Models\Admin::factory()->create([
        //     'email' => 'petmalumarjon.01@gmail.com',
        //     'name' => 'nojram',
        //     'password' => 'nojram1234',
        //     'role' => 'user'
        // ]);
    }
}

<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;

use App\Models\User;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // \App\Models\User::factory()->create();

        // \App\Models\User::factory()->create([
        //     'name' => 'Test User',
        //     'email' => 'test@example.com',
        // ]);


            // \App\Models\Vehicle::factory()->create([
            //     'user_id' => 1,
            //     'vehicle_model' => 'toyota',
            //     'plate_no' => 'ABC2468'
            // ]);

            // $admins = [
            //     [
            //         'name' => 'admin1',
            //         'email' => 'admin1@email.com',
            //         'password' => bcrypt('admin2468'),
            //         'role' => 'admin',
            //     ],
            // ];
            // foreach($admins as $key => $user){
            //     User::create($user);
            // }
            // \App\Models\parkingFloorB::factory(10)->create();
    }
}

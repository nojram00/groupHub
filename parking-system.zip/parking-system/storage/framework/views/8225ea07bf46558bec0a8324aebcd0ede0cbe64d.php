<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <title>Login</title>
</head>
<body>

   <!--
        For Login Page:
    -->

    
    <div class="min-h-screen py-40 bg-no-repeat min-w-full bg-cover" style="background-image: url('images/bg.png')">

        
        <div class="container mx-auto">

            <div class=" flex justify-center">
                <img src="<?php echo e(asset('images/logo2.png')); ?>" alt="logo" class=" w-60 h-60 mx-20 my-5">
            </div>

            <div class=" w-1/3 rounded-xl mx-auto shadow-lg overflow-hidden flex justify-center" style="background-color: rgba(53, 127, 248, 0.5)">
                
                <div class="w-1/2 py-3 px-4">
                    <form action="signedin" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="flex flex-col my-2">
                            <input type="text" placeholder="Username/Email" name="email" class="border border-blue-900 py-1 px-2 rounded-xl my-1">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class=" text-red-600 text-xs  mt-2">
                                        <?php echo e($message); ?>

                                    </p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <input type="password" placeholder="Password" name="password" class="border border-blue-900 py-1 px-2 rounded-xl my-1">
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class=" text-red-600 text-xs  mt-2">
                                        <?php echo e($message); ?>

                                    </p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        <div class="flex flex-row justify-center">
                            <a href="" class="text-white hover:text-black underline"><h1 class="text-lg font-medium mb-4">Forgot Password?</h1></a>
                        </div>
                        <div class="flex flex-row justify-center">
                            
                            <button class="bg-blue-500 text-white px-7 py-3 rounded-2xl mx-1 my-1 hover:bg-black hover:text-white shadow-black shadow-md">Login</button>
                        </div>
                    </form>

                </div>
            </div>

            
            <div class="w-1/3 rounded-xl mx-auto shadow-lg overflow-hidden flex justify-center my-10 py-5" style="background-color: rgba(53, 127, 248, 0.5)">
                <div class="flex flex-col justify-center content-center">
                    <div>
                        <h1 class=" text-lg font-medium mb-4 text-white">Don't have an account?</h1>
                    </div>
                    <div class="self-center">
                        
                        <a href="register"><button class="bg-blue-500 text-white px-7 py-3 rounded-2xl mx-1 my-1 hover:bg-black hover:text-white shadow-black shadow-md">Register</button></a>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>
</html>


<?php /**PATH D:\GitHub\groupHub\parking-system\resources\views/auth/login.blade.php ENDPATH**/ ?>
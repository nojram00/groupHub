
    <footer>

        <?php echo $__env->make('message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </footer>
</div>

</body>
</html>
<?php /**PATH D:\GitHub\groupHub\parking-system\resources\views//partials/__footer.blade.php ENDPATH**/ ?>
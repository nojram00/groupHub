<?php echo $__env->make('.partials.__admin-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main>


    </main>
<?php echo $__env->make('.partials.__admin-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\GitHub\groupHub\parking-system\resources\views//admin/admin-dashboard.blade.php ENDPATH**/ ?>
<footer>

</footer>


</div>
</body>
</html>
<?php /**PATH D:\GitHub\groupHub\parking-system\resources\views//partials/__admin-footer.blade.php ENDPATH**/ ?>
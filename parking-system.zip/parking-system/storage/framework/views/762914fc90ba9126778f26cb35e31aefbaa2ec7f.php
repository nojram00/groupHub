<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Registration Done</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body>
    <div class="min-h-screen py-5 bg-blue-500">
        

        <main>
            <div class="py-5">
                <h1 class="text-3xl font-bold text-center text-white">Registration Complete</h1>
            </div>

            <div class="container mx-auto flex justify-center flex-col font-semibold content-center">
                <div class=" bg-white self-center w-1/2 h-auto p-10 rounded-xl">
                    <p class=" text-center">Click Continue to login your account</p>
                </div>
                <form action="logout" method="post" class=" w-1/2 justify-center my-10 self-center">
                    <?php echo csrf_field(); ?>
                    <button class="bg-white p-4 text-blue-800 rounded-md hover:bg-slate-900 hover:text-white w-1/4">
                        Continue to Login Page
                    </button>
                </form>


            </div>

        </main>
    </div>
</body>
</html>
<?php /**PATH D:\GitHub\groupHub\parking-system\resources\views/registrationdone.blade.php ENDPATH**/ ?>
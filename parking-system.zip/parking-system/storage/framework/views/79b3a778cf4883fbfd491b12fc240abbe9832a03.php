<?php echo $__env->make('.partials.__header', ['title' => 'SM Parking Dashboard - Notifications'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <main>
            <div class="flex flex-row mt-5">

                
                <div class="bg-slate-400 w-1/4 px-5 py-5 ml-5 flex flex-col" style="background-color: rgba(255, 255, 255, 0.5)">
                    <?php echo $__env->make('.partials.__navmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>


                
                <div class=" bg-blue-300 w-9/12 h-auto float-right mr-5 py-5 px-5">
                    <h1 class="text-left font-bold font-sans text-3xl">Notifications</h1>
                    <div class="w-auto m-3 flex flex-col bg-white rounded-md">
                        <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <form action="delete/<?php echo e($notification->id); ?>" method="POST" class="flex flex-row">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>
                                    <h1 class="p-5 font-semibold flex-grow" style="flex-basis: 70%"><?php echo e($notification->notification); ?></h1>
                                    <button type="submit" class="bg-blue-500 flex-grow m-2 rounded-md">Delete</button>
                                </form>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

            </div>
        </main>

<?php echo $__env->make('.partials.__footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\GitHub\groupHub\parking-system\resources\views//dashboard/notifications.blade.php ENDPATH**/ ?>
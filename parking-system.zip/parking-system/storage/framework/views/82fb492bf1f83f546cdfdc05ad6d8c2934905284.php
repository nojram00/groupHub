<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <title>Confirm Parking for Parking Slot <?php echo e($parkingID); ?></title>
</head>
<body>

    <div class=" bg-blue-500 min-h-screen py-5">
        <?php echo $__env->make('confirmation-prompt', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <header>
            <div class=" bg-white w-auto h-1/4 p-10">
                <h1 class=" text-center font-bold text-2xl">Confirm Parking for Slot <?php echo e($parkingID); ?></h1>
            </div>
        </header>
        <main class="flex justify-center">
            <div class="my-5 py-5 w-1/2 h-auto font-bold text-xl text-white rounded-lg px-5 flex flex-col justify-center content-center text-center space-y-4" style="background-color:rgba(0, 0, 0, .5)">
                <h1>Parking No.: <?php echo e($parkingID); ?></h1>
                <h1>Last time updated: <br> <?php echo e($parkingTime); ?></h1>
                <?php if($pStatus == 0): ?>
                    <h1 class=" text-green-400 "><?php echo e($status); ?></h1>
                <?php else: ?>
                    <h1 class=" text-red-400 "><?php echo e($status); ?></h1>
                    <h1>Parked By: <?php echo e($parked_user); ?></h1>
                    <h1>Plate Number: <?php echo e($plate_no); ?></h1>
                <?php endif; ?>

                <div class="flex flex-col w-auto justify-center content-center">
                    <?php if($pStatus == 0): ?>
                        <?php $__currentLoopData = $vehicle_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <a href="/parking/confirm/<?php echo e($floor); ?>/<?php echo e($parkingID); ?>/<?php echo e($vehicle->vehicle_model); ?>">
                                <h1 class="bg-slate-200 p-4 text-blue-800 rounded-md hover:bg-slate-900 hover:text-white w-auto m-2">Park Here as <?php echo e($vehicle->vehicle_model); ?>, <?php echo e($vehicle->plate_no); ?></h1>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>

                <a href="/back/<?php echo e($floor); ?>">
                    <button class=" bg-slate-200 p-4 text-blue-800 rounded-md hover:bg-slate-900 hover:text-whit w-1/4">
                        Back
                    </button>
                </a>
            </div>
        </main>
    </div>
</body>
</html>
<?php /**PATH D:\GitHub\groupHub\parking-system\resources\views/parking-confirmation.blade.php ENDPATH**/ ?>
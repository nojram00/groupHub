<?php echo $__env->make('.partials.__header', ['title' => session('title')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php
    $floor = 1
?>
<main>
    <div class="flex flex-row mt-5">

        
        <div class="bg-slate-400 w-1/4 px-5 py-5 ml-5 flex flex-col rounded-lg  " style="background-color: rgba(255, 255, 255, 0.5)">
            <?php echo $__env->make('.partials.__navmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>


        
        <div class=" bg-blue-300 w-1/2 h-auto float-right mx-5 py-5 px-5 rounded-lg ">
            <h1 class="text-left font-bold font-sans text-3xl"><?php echo e($header); ?></h1>

            <div class=" py-3 px-3 flex flex-col space-y-6">
                <div id="column-1" class=" flex flex-row space-x-6">
                    <?php $__currentLoopData = $floorLevel_A; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="parking/<?php echo e($floor); ?>/<?php echo e($fd->parking_id); ?>">
                            <div class=" w-32 bg-slate-300 h-40 flex flex-col content-center justify-center hover:bg-slate-800 hover:text-white rounded-md" id="parking-slot">
                                <h1 class=" text-center font-semibold text-black" id="parking-info"> <?php echo e($fd->parking_id); ?> </h1>
                                <h1 class=" text-center font-semibold text-black" id="parking-info">Time-in: <br> <?php echo e($fd->time_parking); ?> </h1>
                                <?php if($fd->isAvailable == 0): ?>
                                    <h1 class=" text-center font-semibold text-green-500"> Available </h1>
                                <?php else: ?>
                                    <h1 class=" text-center font-semibold text-red-500"> Unavailable </h1>
                                <?php endif; ?>
                             </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div id="column-2" class=" flex flex-row space-x-6">
                    <?php $__currentLoopData = $floorLevel_B; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="parking/<?php echo e($floor); ?>/<?php echo e($fd->parking_id); ?>">
                        <div class=" w-32 bg-slate-300 h-40 flex flex-col content-center justify-center hover:bg-slate-800 hover:text-white rounded-md" id="parking-slot">
                            <h1 class=" text-center font-semibold text-black" id="parking-info"> <?php echo e($fd->parking_id); ?> </h1>
                            <h1 class=" text-center font-semibold text-black" id="parking-info">Time-in: <br> <?php echo e($fd->time_parking); ?> </h1>
                            <?php if($fd->isAvailable == 0): ?>
                                <h1 class=" text-center font-semibold text-green-500"> Available </h1>
                            <?php else: ?>
                                <h1 class=" text-center font-semibold text-red-500"> Unavailable </h1>
                            <?php endif; ?>
                        </div>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

        </div>

        <aside class="w-1/2 mx-5 h-auto bg-white rounded-xl">
            <?php echo $__env->make('.partials.__carreg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </aside>
    </div>
</main>


<?php echo $__env->make('.partials.__footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\GitHub\groupHub\parking-system\resources\views//parkingfloors/floors.blade.php ENDPATH**/ ?>
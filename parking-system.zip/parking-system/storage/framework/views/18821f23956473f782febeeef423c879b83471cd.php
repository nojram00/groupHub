<?php echo $__env->make('.partials.__admin-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main>
        <h1>Send Notification Status</h1>
        <form action="/notifs" method="POST">
            <?php echo csrf_field(); ?>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input type="radio" name="user_name" value="<?php echo e($u->name); ?>" id="">
                <label for="user_name"><?php echo e($u->name); ?></label> <br>
                <input type="hidden" name="user_id" value="<?php echo e($u->id); ?>">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            <button type="submit" value="parking_alert" name="notification" class="bg-white text-blue-900 p-3 m-4 rounded-md w-1/4 font-bold">Send Alert</button>
            <button type="submit" value="thanks" name="notification" class="bg-white text-blue-900 p-3 m-4 rounded-md w-1/4 font-bold">Send</button>
        </form>
    </main>
<?php echo $__env->make('.partials.__admin-footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\GitHub\groupHub\parking-system\resources\views//admin/admin-notification.blade.php ENDPATH**/ ?>
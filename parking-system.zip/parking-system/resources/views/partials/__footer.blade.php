
    <footer>

        @include('message')

    </footer>
</div>

</body>
</html>

@include('.partials.__admin-header')
    <main>


    </main>
@include('.partials.__admin-footer')
